<?php
/** Make sure that the WordPress bootstrap has run before continuing. */
require __DIR__ . '/wp-load.php';

session_start();
if (isset($_SESSION['2fa-user-login'])) {
    $currentUser = get_user_by('login', $_SESSION['2fa-user-login']);
    if (isset($_POST['code'])) {
        $tfa_code = get_user_meta($currentUser->ID, 'tfa_code', true);
        if ($tfa_code === $_POST['code']) {
            // Clear $_SESSION
            $_SESSION = array();
            // Login user into the platform
            wp_set_current_user($currentUser->ID, $currentUser->data->user_login);
            wp_set_auth_cookie($currentUser->ID);
            do_action('wp_login', $currentUser->data->user_login, $currentUser);
            // Set user as logged successfully in 2FA
            update_user_meta($currentUser->ID, 'tfa_logged', '1');
            // Redirect user to platform
            wp_redirect(site_url());
        } else {
            $errorMessage = 'The entered code is incorrect.';
        }
    } else {
        $infoMessage = 'Please enter the code that was sent to your email, linked to your account.';
    }
} else {
    wp_redirect(home_url());
}
?>

<!DOCTYPE html>
	<!--[if IE 8]>
		<html xmlns="http://www.w3.org/1999/xhtml" class="ie8" <?php language_attributes();?>>
	<![endif]-->
	<!--[if !(IE 8) ]><!-->
		<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes();?>>
	<!--<![endif]-->
	<head>
	<meta http-equiv="Content-Type" content="<?php bloginfo('html_type');?>; charset=<?php bloginfo('charset');?>" />
	<title>2FA Auth</title>
	<link rel="stylesheet" href="http://localhost/wordpress/wp-admin/load-styles.php?c=1&amp;dir=ltr&amp;load%5Bchunk_0%5D=dashicons,buttons,forms,l10n,login&amp;ver=5.4.2" type="text/css" media="all">

	<?php

/**
 * Enqueue scripts and styles for the login page.
 *
 * @since 3.1.0
 */
do_action('login_enqueue_scripts');

/**
 * Fires in the login page header after scripts are enqueued.
 *
 * @since 2.1.0
 */
do_action('login_head');

$login_header_url = __('https://wordpress.org/');

?>
	</head>
	<body class="login no-js login-action-login wp-core-ui  locale-en-us">
	<div id="login">
	<?php
// Messages
if (!empty($errorMessage)) {
    ?>
    	<div id="login_error"><?php echo $errorMessage; ?></div>
	<?php
}

if (!empty($infoMessage)) {
    ?>
		<p class="message"><?php echo $infoMessage; ?></p>
	<?php
}
?>
	<form name="loginform" id="loginform" action="<?php echo esc_url(site_url() . "/2fa-auth.php"); ?>" method="post">
			<p>
				<label for="2fa_code">Code:</label>
				<input type="text" name="code" class="input" value="" size="20" autocapitalize="off" required />
			</p>
			<p class="submit">
				<input type="submit" name="wp-submit" id="wp-submit" class="button button-primary button-large" value="Send" />
			</p>
		</form>
	</div>
</body>
