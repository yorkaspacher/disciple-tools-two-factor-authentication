<?php
/**
 * DT_2FA_Authentication_Plugin_Menu class for the admin page
 *
 * @class       DT_2FA_Authentication_Plugin_Menu
 * @version     0.1.0
 * @since       0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; // Exit if accessed directly
}

/**
 * Initialize menu class
 */
DT_2FA_Authentication_Plugin_Menu::instance();

/**
 * Class DT_2FA_Authentication_Plugin_Menu
 */
class DT_2FA_Authentication_Plugin_Menu {

    public $token = 'dt_2fa_authentication_plugin';

    private static $_instance = null;

    /**
     * DT_2FA_Authentication_Plugin_Menu Instance
     *
     * Ensures only one instance of DT_2FA_Authentication_Plugin_Menu is loaded or can be loaded.
     *
     * @since 0.1.0
     * @static
     * @return DT_2FA_Authentication_Plugin_Menu instance
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    } // End instance()


    /**
     * Constructor function.
     * @access  public
     * @since   0.1.0
     */
    public function __construct() {

        add_action( "admin_menu", array( $this, "register_menu" ) );

    } // End __construct()


    /**
     * Loads the subnav page
     * @since 0.1
     */
    public function register_menu() {
        add_menu_page( __( 'Extensions (DT)', 'disciple_tools' ), __( 'Extensions (DT)', 'disciple_tools' ), 'manage_dt', 'dt_extensions', [ $this, 'extensions_menu' ], 'dashicons-admin-generic', 59 );
        add_submenu_page( 'dt_extensions', __( 'Two Factor Authentication', 'dt_2fa_authentication_plugin' ), __( 'Two Factor Authentication', 'dt_2fa_authentication_plugin' ), 'manage_dt', $this->token, [ $this, 'content' ] );
    }

    /**
     * Menu stub. Replaced when Disciple Tools Theme fully loads.
     */
    public function extensions_menu() {}

    /**
     * Builds page contents
     * @since 0.1
     */
    public function content() {

        if ( !current_user_can( 'manage_dt' ) ) { // manage dt is a permission that is specific to Disciple Tools and allows admins, strategists and dispatchers into the wp-admin
            wp_die( esc_attr__( 'You do not have sufficient permissions to access this page.' ) );
        }

        if ( isset( $_GET["tab"] ) ) {
            $tab = sanitize_key( wp_unslash( $_GET["tab"] ) );
        } else {
            $tab = 'general';
        }

        $link = 'admin.php?page='.$this->token.'&tab=';

        if (isset($_POST['submitEmail'])) {

            $settings = json_decode(get_option('2fa_settings'), true);

            $email = sanitize_text_field($_POST['emailOption']);
            $message = sanitize_text_field($_POST['messageOption']);

            $settings["email"] = $email ? $email : $settings["email"];
            $settings["message"] = $message ? $message : $settings["message"];

            update_option('2fa_settings', json_encode($settings));
        }

        $generalSettings = json_decode(get_option('2fa_settings'));

        ?>
        <div class="wrap">
        
            <h2 class="wp-heading-inline"><?php esc_attr_e( 'Two Factor Authentication', 'dt_2fa_authentication_plugin' ) ?></h2> 
            <br>
            <button class="page-title-action" id="buttonHideForm" style="display:none" onclick="hideForm()">Close</button>
            <br>

            <div id="formToChangeEmail" style="display: none;">
                <br>
                <br>
                <form action="" method="post" enctype="multipart/form-data" class="form-basic">
            
                    <table class="wp-list-table widefat striped users" style="padding: 10px 0;">
                        <tbody>
                            <tr style="background: transparent;">
                                <td style="vertical-align: inherit;">
                                    <label style="display: block;">Email (*)</label>
                                    <input type="email" name="emailOption" id="emailOption" require>
                                </td>
                                <td style="vertical-align: inherit;">
                                    <label style="display: block;">Message (*)</label>
                                    <textarea name="messageOption" id="messageOption" cols="30" rows="3"></textarea>
                                </td>
                            </tr>
                        </tbody>
                    </table>

                    <p class="submit" style="text-align: center">
                        <button type="submit" name="submitEmail" id="submitEmail" class="button button-primary">Submit Form</button>
                    </p>

                </form>
            </div>
            
            <table class="wp-list-table widefat striped users">
                <thead>
                    <tr>
                        <th width="200">Email</th>
                        <th>Message</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>
                        <?php echo $generalSettings->email ?>  <br>
                            <label>
                                <a onclick="showForm('')">Edit</a>
                            </label>
                        </td>
                        <td><?php echo $generalSettings->message ?></td>
                        <!-- <td><?php echo $option->label ?></td> -->
                    </tr>
                </tbody>
            </table>

        </div>

        <script>
        
        function showForm (){

            var settings = <?php echo json_encode($generalSettings); ?>;

            document.getElementById("emailOption").value = settings.email
            document.getElementById("messageOption").value = settings.message

            document.getElementById('formToChangeEmail').style.display = 'block'
            document.getElementById('buttonHideForm').style.display = 'inline-block'
}
        
        function hideForm (){
            document.getElementById('formToChangeEmail').style.display = 'none'
            document.getElementById('buttonHideForm').style.display = 'none'
        }

        </script>

        <?php
    }
}

