.po and .mo files must be in this format:  
{translation-domain}-{localisation}.po
 
ex:  
dt_2fa_authentication_plugin.fr_FR.po